# 📚 LiterAlura

<img width="100%" src="https://capsule-render.vercel.app/api?type=waving&height=200&color=gradient&fontColor=7700ff"/>

Aplicação **Java** com **Spring** que consome a API pública **[Gutendex](https://gutendex.com/)** para listar livros, exibir autores e salvar informações em banco de dados. Projeto desenvolvido como prática de consumo de **APIs REST** e persistência de dados.

---

## 🛠 Tecnologias utilizadas

- Java 21
- Spring
- Maven
- JPA + Hibernate
- PostgreSQL
- API [Gutendex](https://gutendex.com/)
- IntelliJ IDEA

---

## 🚀 Como executar o projeto

### Rodando o projeto

```bash
# Clone o repositório

git clone https://github.com/seu-usuario/literalura.git
cd literalura

# Execute com o Maven Wrapper

./mvnw spring-boot:run
```

💡 Ou, se preferir, importe na sua IDE favorita e rode a classe `LiterAluraApplication`.

---

## ⚙️ Configuração do `application.properties`

No arquivo `src/main/resources/application.properties`, configure:

```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/literalura
spring.datasource.username=SEU_USERNAME
spring.datasource.password=SUA_SENHA
spring.jpa.hibernate.ddl-auto=update
```

---

## 📌 Funcionalidades

- 🔍 Buscar livros por título
- 👤 Exibir autores e datas de nascimento
- 🌍 Listar idiomas disponíveis
- 💾 Persistência dos dados em banco
- 📊 Filtrar por autor, idioma ou período
- 📚 Visualização organizada no terminal

---

## 🌟 Inspiração

Projeto desenvolvido com base no desafio liteAlura da plataforma **Alura**.

<img width="100%" src="https://capsule-render.vercel.app/api?type=waving&height=200&color=gradient&fontColor=d900ff&section=footer"/>
