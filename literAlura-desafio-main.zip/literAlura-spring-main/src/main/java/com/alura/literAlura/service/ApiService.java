package com.alura.literAlura.service;

import com.alura.literAlura.dto.DadosResultado;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Service
public class ApiService {

    private static final String BASE_URL = "https://gutendex.com/books";

    private final RestTemplate restTemplate;

    public ApiService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public DadosResultado buscarLivrosPorTitulo(String titulo) {
        String url = UriComponentsBuilder.fromHttpUrl(BASE_URL)
                .queryParam("search", titulo)
                .toUriString();

        return restTemplate.getForObject(url, DadosResultado.class);
    }
}
