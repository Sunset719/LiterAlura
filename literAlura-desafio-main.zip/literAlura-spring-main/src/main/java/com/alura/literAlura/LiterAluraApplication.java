package com.alura.literAlura;

import com.alura.literAlura.service.MenuService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LiterAluraApplication {

	public static void main(String[] args) {
		var context = SpringApplication.run(LiterAluraApplication.class, args);

		MenuService menu = context.getBean(MenuService.class);
		menu.exibirMenu();
	}
}
