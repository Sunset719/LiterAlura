package com.alura.literAlura.service;

import com.alura.literAlura.dto.DadosLivro;
import com.alura.literAlura.dto.DadosResultado;
import com.alura.literAlura.model.Autor;
import com.alura.literAlura.model.Livro;
import com.alura.literAlura.util.ConsoleUtil;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Scanner;

@Service
public class MenuService {

    private final Scanner scanner = new Scanner(System.in);
    private final ApiService apiService;
    private final LivroService livroService;

    public MenuService(ApiService apiService, LivroService livroService) {
        this.apiService = apiService;
        this.livroService = livroService;
    }

    public void exibirMenu() {
        int opcao;
        do {
            ConsoleUtil.limparConsole();
            System.out.println("""
                ===== MENU PRINCIPAL =====
                1 - Buscar livros por título
                2 - Listar todos os livros
                3 - Listar todos os autores
                4 - Listar autores vivos em um ano
                5 - Listar livros por idioma
                0 - Sair
                """);
            opcao = ConsoleUtil.lerInteiro("Escolha uma opção: ");

            switch (opcao) {
                case 1 -> buscarLivrosPorTitulo();
                case 2 -> listarLivros(livroService.listarTodosLivros());
                case 3 -> listarAutores(livroService.listarTodosAutores());
                case 4 -> listarAutoresVivosPorAno();
                case 5 -> listarLivrosPorIdioma();
                case 0 -> System.out.println("Encerrando...");
                default -> System.out.println("Opção inválida!");
            }

            if (opcao != 0) ConsoleUtil.pausar();
        } while (opcao != 0);
    }

    private void buscarLivrosPorTitulo() {
        System.out.print("Digite o título para busca: ");
        String titulo = scanner.nextLine();

        DadosResultado resultado = apiService.buscarLivrosPorTitulo(titulo);

        if (resultado.results().isEmpty()) {
            System.out.println("Nenhum livro encontrado.");
            return;
        }

        resultado.results().forEach(dto -> {
            livroService.salvarLivro(dto);

            String nomeAutor = dto.autores().isEmpty() ? "Desconhecido" : dto.autores().get(0).nome();
            String idioma = dto.idiomas().isEmpty() ? "Desconhecido" : dto.idiomas().get(0);

            System.out.printf("""
                Título: %s
                Autor: %s
                Idioma: %s
                Downloads: %d
                -----------------------
                """,
                    dto.titulo(), nomeAutor, idioma, dto.downloads());
        });

        System.out.printf("%d livros adicionados.%n", resultado.results().size());
    }

    private void listarLivros(List<Livro> livros) {
        if (livros.isEmpty()) {
            System.out.println("Nenhum livro encontrado.");
            return;
        }

        livros.forEach(l -> {
            System.out.printf("""
                Título: %s
                Autor: %s
                Idioma: %s
                Downloads: %d
                -----------------------
                """,
                    l.getTitulo(),
                    l.getAutor() != null ? l.getAutor().getNome() : "Desconhecido",
                    l.getIdioma() != null ? l.getIdioma() : "Desconhecido",
                    l.getDownloads());
        });
    }

    private void listarAutores(List<Autor> autores) {
        if (autores.isEmpty()) {
            System.out.println("Nenhum autor salvo.");
            return;
        }

        autores.forEach(a -> System.out.printf("- %s (%s - %s)%n",
                a.getNome(),
                a.getAnoNascimento() != null ? a.getAnoNascimento() : "?",
                a.getAnoFalecimento() != null ? a.getAnoFalecimento() : "Presente"));
    }

    private void listarAutoresVivosPorAno() {
        int ano = ConsoleUtil.lerInteiro("Digite o ano para verificar autores vivos: ");
        listarAutores(livroService.listarAutoresVivosNoAno(ano));
    }

    private void listarLivrosPorIdioma() {
        System.out.print("Digite o idioma desejado (ex: en, pt): ");
        String idioma = scanner.nextLine().trim();

        listarLivros(livroService.listarLivrosPorIdioma(idioma));
    }
}
