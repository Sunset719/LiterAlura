package com.alura.literAlura.service;

import com.alura.literAlura.dto.DadosLivro;
import com.alura.literAlura.model.Autor;
import com.alura.literAlura.model.Livro;
import com.alura.literAlura.repository.AutorRepository;
import com.alura.literAlura.repository.LivroRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LivroService {

    private final LivroRepository livroRepository;
    private final AutorRepository autorRepository;

    public LivroService(LivroRepository livroRepository, AutorRepository autorRepository) {
        this.livroRepository = livroRepository;
        this.autorRepository = autorRepository;
    }

    public void salvarLivro(DadosLivro dados) {
        Autor autor = dados.autores().isEmpty()
                ? null
                : dados.autores().stream()
                .findFirst()
                .map(d -> autorRepository
                        .findByNome(d.nome())
                        .orElseGet(() -> autorRepository.save(new Autor(
                                d.nome(),
                                d.anoNascimento(),
                                d.anoFalecimento()))))
                .orElse(null);

        String idiomaPrincipal = dados.idiomas().isEmpty() ? null : dados.idiomas().get(0);

        Livro livro = new Livro(
                dados.titulo(),
                idiomaPrincipal,
                dados.downloads(),
                autor
        );

        livroRepository.save(livro);
    }

    public List<Livro> listarTodosLivros() {
        return livroRepository.findAllComAutor();
    }

    public List<Autor> listarTodosAutores() {
        return autorRepository.findAll();
    }

    public List<Autor> listarAutoresVivosNoAno(int ano) {
        return autorRepository.findAll().stream()
                .filter(a -> a.getAnoNascimento() != null && a.getAnoNascimento() <= ano)
                .filter(a -> a.getAnoFalecimento() == null || a.getAnoFalecimento() >= ano)
                .toList();
    }

    public List<Livro> listarLivrosPorIdioma(String idioma) {
        return livroRepository.findByIdiomaComAutor(idioma);
    }
}
